//
//  ViewController.swift
//  FireBaseDemo
//
//  Created by om technology on 01/05/19.
//  Copyright © 2019 Panini Academy. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import RaisePlaceholder
protocol alertView {
    func Alert(title:String,massage:String,delegate:AnyObject)
    }
class ViewController: UIViewController {
    var delegate:alertView!
    
    @IBOutlet var txtUserName: RaisePlaceholder!  //txtusername login
    @IBOutlet var txtPassword: RaisePlaceholder!   //txtpassword Login
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    //MArk:go to Forget Password
    @IBAction func btnGotoForGatePassword(_ sender: Any)
    {
        let gotoForGetPAssword = self.storyboard?.instantiateViewController(withIdentifier: "ResetPasswordViewController") as! ResetPasswordViewController
        self.navigationController?.pushViewController(gotoForGetPAssword, animated: true)
    }
    
    //mark: btn go to Home Page
    
    @IBAction func BtnLogin(_ sender: Any)
    {
        if txtUserName.text == ""
        {
           Alert(title: "Enter UserName", massage: "", delegate: self)
        }else if txtPassword.text == ""
        {
           Alert(title: "Plese Enter Password", massage: "", delegate: self)
        }else
        {
            Auth.auth().signIn(withEmail: self.txtUserName.text!, password: self.txtPassword.text!) { (user, error) in

            if error == nil {
                                
                //Go to the HomeViewController if the login is sucessful
                let homePage = self.storyboard?.instantiateViewController(withIdentifier: "HomePageViewController") as! HomePageViewController
                self.navigationController?.pushViewController(homePage, animated: true)
                
            } else {
                
                //Tells the user that there is an error and then gets firebase to tell them the error
                self.Alert(title: "Error", massage: (error?.localizedDescription)!, delegate: self)
            }
            
            
        }
      }
    }
    
     //btn go to Sighn Up page
    
    @IBAction func btnGotoSighnInpage(_ sender: Any)
    {
        let sighnUpPage = self.storyboard?.instantiateViewController(withIdentifier: "sighnupViewController") as! sighnupViewController
        self.navigationController?.pushViewController(sighnUpPage, animated: true)
    }
    //mark: alert Function
   
}

