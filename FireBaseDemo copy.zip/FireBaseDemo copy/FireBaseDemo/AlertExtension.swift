//
//  AlertExtension.swift
//  FireBaseDemo
//
//  Created by om technology on 01/05/19.
//  Copyright © 2019 Panini Academy. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController
 {
    func Alert(title:String,massage:String,delegate:AnyObject)
    {
        let alert = UIAlertView()
        alert.title = title
        alert.message = massage
        alert.addButton(withTitle: "ok")
        alert.delegate = delegate
        alert.show()
    }
 }
