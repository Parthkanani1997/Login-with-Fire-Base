//
//  ResetPasswordViewController.swift
//  FireBaseDemo
//
//  Created by om technology on 01/05/19.
//  Copyright © 2019 Panini Academy. All rights reserved.
//

import UIKit
import RaisePlaceholder
import Firebase
import FirebaseAuth

class ResetPasswordViewController: UIViewController {

    @IBOutlet var txtResetEmail: RaisePlaceholder!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    @IBAction func btnResetPassword(_ sender: Any)
    {
        if txtResetEmail.text == "" {
            Alert(title: "opps Enter Email", massage: "", delegate: self)
        }else {
            Auth.auth().sendPasswordReset(withEmail: self.txtResetEmail.text!, completion: { (error) in
                
                var title = ""
                var message = ""
                
                if error != nil {
                    title = "Error!"
                    message = (error?.localizedDescription)!
                } else {
                    title = "Success!"
                    message = "Password reset email sent."
                    self.txtResetEmail.text = ""
                }
                
             self.Alert(title: title, massage: message, delegate: self)
            })
        }
    }
    
    @IBAction func btngoToLoginpage(_ sender: Any)
    {
      let gotoLoginPage = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(gotoLoginPage, animated: true)
    }
    
    @IBAction func btnGOtoSighninPage(_ sender: Any)
    {
      let gotoSighnUpPage = self.storyboard?.instantiateViewController(withIdentifier: "sighnupViewController") as! sighnupViewController
        self.navigationController?.pushViewController(gotoSighnUpPage, animated: true)
    }
}
