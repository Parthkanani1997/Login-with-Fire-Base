//
//  sighnupViewController.swift
//  FireBaseDemo
//
//  Created by om technology on 01/05/19.
//  Copyright © 2019 Panini Academy. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import RaisePlaceholder
class sighnupViewController: UIViewController {
   
    

    @IBOutlet var txtUserName: RaisePlaceholder! //new user Username
    @IBOutlet var txtEmail: RaisePlaceholder!   //new User Email
    @IBOutlet var txtPassword: RaisePlaceholder! //new User Password
    @IBOutlet var txtRepassword: RaisePlaceholder! //new User Re-Password
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
         //btn Sighn for go to home page
    @IBAction func btnSighn(_ sender: Any)
    {
        if txtUserName.text == "" {
            Alert(title: "Enter UserName", massage: "", delegate: self)
        } else if txtEmail.text == ""
        {
            Alert(title: "Enter Email", massage: "", delegate: self)
        }else if txtPassword.text == ""
        {
            Alert(title: "Enter Password", massage: "", delegate: self)
        }else if txtRepassword.text == ""
        {
            Alert(title: "Enter repassword", massage: "", delegate: self)
        }else if ((txtPassword.text! .elementsEqual(txtRepassword.text!)) == false)
        {
            Alert(title: "PassWord are Not match", massage: "", delegate: self)
        }else
        {
            Auth.auth().createUser(withEmail: txtEmail.text!, password: txtPassword.text!) { (user, error) in
                
                if error == nil {
                    print("You have successfully signed up")
                    //Goes to the Setup page which lets the user take a photo for their profile picture and also chose a username
                    let homePage = self.storyboard?.instantiateViewController(withIdentifier: "HomePageViewController") as! HomePageViewController
                    self.navigationController?.pushViewController(homePage, animated: true)
                    
                } else {
                    self.Alert(title: "error", massage: (error?.localizedDescription)!, delegate: self)
                   
                }
            }
            
        }
       
    }
      //button back
    @IBAction func btnBack(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
    }
    

}
