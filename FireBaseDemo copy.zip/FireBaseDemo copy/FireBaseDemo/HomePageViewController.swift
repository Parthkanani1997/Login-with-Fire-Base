//
//  HomePageViewController.swift
//  FireBaseDemo
//
//  Created by om technology on 01/05/19.
//  Copyright © 2019 Panini Academy. All rights reserved.
//

import UIKit
import FirebaseAuth
import Firebase
class HomePageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    @IBAction func btnLogOut(_ sender: Any)
    {
        if Auth.auth().currentUser != nil {
            do {
                let loginPage = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
                self.navigationController?.pushViewController(loginPage, animated: true)
                try Auth.auth().signOut()
                
                
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
        
    }
    
}
